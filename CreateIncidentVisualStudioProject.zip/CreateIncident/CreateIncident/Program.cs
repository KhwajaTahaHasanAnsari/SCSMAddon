﻿/*
 CreateIncident.exe
 
 Description:
 CreateIncident.exe creates objects of the Sytsem.WorkItem.Incident class in
 the System Center Service Manager management group it is pointed to.
 Parameters can be passed on the command line to set properties of the new incident.
 
 Copyright(c) Microsoft.  All rights reserved.
 This code is licensed under the Microsoft Public License.
 http://www.microsoft.com/opensource/licenses.mspx
 
 THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING ANY IMPLIED WARRANTIES
 OF FITNESS FOR A PARITCULAR PURPOSE, MERCHANTABILITY, OR
 NON-INFRINGEMENT.
 
 Original Author: Travis Wright (twright@microsoft.com)
 Original Creation Date: Dec 7, 2009
 Original Version: 1.0
*/ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.EnterpriseManagement;
using Microsoft.EnterpriseManagement.Common;
using Microsoft.EnterpriseManagement.Configuration;
using CommadLineArgumentParser;

namespace CreateIncident
{
    class Program
    {
        static void Main(string[] args)
        {

#region Variables
            string strDisplayName = null;
            string strID = null;
            string strTitle = null;
            string strDescription = null;
            string strContactMethod = null;

            string strUrgency = null;
            string strUrgencyMP = null;
            string strUrgencyMPKeyToken = null;
            string strUrgencyMPVersion = null;
            Guid guidUrgency = new Guid();
            Version verUrgencyMPVersion;

            string strImpact = null;
            string strImpactMP = null;
            string strImpactMPKeyToken = null;
            string strImpactMPVersion = null;
            Guid guidImpact = new Guid();
            Version verImpactMPVersion;

            string strStatus = null;
            string strStatusMP = null;
            string strStatusMPKeyToken = null;
            string strStatusMPVersion = null;
            Guid guidStatus = new Guid();
            Version verStatusMPVersion;

            string strTier = null;
            string strTierMP = null;
            string strTierMPKeyToken = null;
            string strTierMPVersion = null;
            Guid guidTier = new Guid();
            Version verTierMPVersion;

            string strClassification = null;
            string strClassificationMP = null;
            string strClassificationMPKeyToken = null;
            string strClassificationMPVersion = null;
            Guid guidClassification = new Guid();
            Version verClassificationMPVersion;

            string strSource = null;
            string strSourceMP = null;
            string strSourceMPKeyToken = null;
            string strSourceMPVersion = null;
            Guid guidSource = new Guid();
            Version verSourceMPVersion;

            string strServerName = null; 
#endregion

            try
            {

#region ProcessCommandLineArguments

                CommadLineArgumentParser.Arguments strArrayArguments = new Arguments(args);

#region DisplayUsage
                //Check to see if any of the arguments is /? indicating the user is asking for usage
                if (strArrayArguments["?"] == "true")
                {
                    Console.WriteLine("\n");
                    Console.WriteLine("*******************************  CreateIncident.exe Usage  ********************************");
                    Console.WriteLine("\n");
                    Console.WriteLine("CreateIncident.exe takes the following optional command line parameters:");
                    Console.WriteLine("\n");
                    Console.WriteLine("DisplayName" + "\t" + "\t" + "\t" + "The display name for the incident.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("Title" + "\t" + "\t" + "\t" + "\t" + "The title for the incident.  Typically the same as the display name.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("Description" + "\t" + "\t" + "\t" + "Description is typically a longer explanation than the title.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("IDPrefix" + "\t" + "\t" + "\t" + "The ID prefix.  For example 'IR-' will result in an ID of 'IR-####'");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("ContactMethod" + "\t" + "\t" + "\t" + "The contact method describes how the affected user can be contacted.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("Urgency" + "\t" + "\t" + "\t" + "\t" + "The ID of the Urgency EnumerationValue element from the management pack.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System.WorkItem.TroubleTicket.UrgencyEnum.Medium");
                    Console.WriteLine("\n");
                    Console.WriteLine("UrgencyMP" + "\t" + "\t" + "\t" + "The ID of the management pack that contains the Urgency EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System.WorkItem.Library");
                    Console.WriteLine("\n");
                    Console.WriteLine("UrgencyMPKeyToken" + "\t" + "\t" + "The KeyToken of the management pack that contains the Urgency EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System KeyToken");
                    Console.WriteLine("\n");
                    Console.WriteLine("UrgencyMPVersion" + "\t" + "\t" + "The Version of the management pack that contains the Urgency EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System Version");
                    Console.WriteLine("\n");
                    Console.WriteLine("UrgencyGUID" + "\t" + "\t" + "\t" + "The GUID of the Urgency EnumerationValue.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("Impact" + "\t" + "\t" + "\t" + "\t" + "The ID of the Impact EnumerationValue element from the management pack.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System.WorkItem.TroubleTicket.ImpactEnum.Medium");
                    Console.WriteLine("\n");
                    Console.WriteLine("ImpactMP" + "\t" + "\t" + "\t" + "The ID of the management pack that contains the Impact EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System.WorkItem.Library");
                    Console.WriteLine("\n");
                    Console.WriteLine("ImpactMPKeyToken" + "\t" + "\t" + "The KeyToken of the management pack that contains the Impact EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System KeyToken");
                    Console.WriteLine("\n");
                    Console.WriteLine("ImpactMPVersion" + "\t" + "\t" + "\t" + "The Version of the management pack that contains the Impact EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System Version");
                    Console.WriteLine("\n");
                    Console.WriteLine("ImpactGUID" + "\t" + "\t" + "\t" + "The GUID of the Impact EnumerationValue.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("Status" + "\t" + "\t" + "\t" + "\t" + "The ID of the Status EnumerationValue element from the management pack.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: IncidentStatusEnum.Active");
                    Console.WriteLine("\n");
                    Console.WriteLine("StatusMP" + "\t" + "\t" + "\t" + "The ID of the management pack that contains the Status EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System.WorkItem.Incident.Library");
                    Console.WriteLine("\n");
                    Console.WriteLine("StatusMPKeyToken" + "\t" + "\t" + "The KeyToken of the management pack that contains the Status EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System KeyToken");
                    Console.WriteLine("\n");
                    Console.WriteLine("StatusMPVersion" + "\t" + "\t" + "\t" + "The Version of the management pack that contains the Status EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System Version");
                    Console.WriteLine("\n");
                    Console.WriteLine("StatusGUID" + "\t" + "\t" + "\t" + "The GUID of the Status EnumerationValue.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("Tier" + "\t" + "\t" + "\t" + "\t" + "The ID of the Tier EnumerationValue element from the management pack.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("TierMP" + "\t" + "\t" + "\t" + "\t" + "The ID of the management pack that contains the Tier EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: ServiceManager.IncidentManagement.Configuration");
                    Console.WriteLine("\n");
                    Console.WriteLine("TierMPKeyToken" + "\t" + "\t" + "\t" + "The KeyToken of the management pack that contains the Tier EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("TierMPVersion" + "\t" + "\t" + "\t" + "The Version of the management pack that contains the Tier EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System Version");
                    Console.WriteLine("\n");
                    Console.WriteLine("TierGUID" + "\t" + "\t" + "\t" + "The GUID of the Tier EnumerationValue.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("Classification" + "\t" + "\t" + "\t" + "The ID of the Classification EnumerationValue element from the management pack.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("ClassificationMP" + "\t" + "\t" + "The ID of the management pack that contains the Classification EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: ServiceManager.IncidentManagement.Configuration");
                    Console.WriteLine("\n");
                    Console.WriteLine("ClassificationMPKeyToken" + "\t" + "The KeyToken of the management pack that contains the Classification EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("ClassificationMPVersion" + "\t" + "\t" + "The Version of the management pack that contains the Classification EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System Version");
                    Console.WriteLine("\n");
                    Console.WriteLine("ClassificationGUID" + "\t" + "\t" + "The GUID of the Classification EnumerationValue.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("Source" + "\t" + "\t" + "\t" + "\t" + "The ID of the Source EnumerationValue element from the management pack.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: IncidentSourceEnum.System");
                    Console.WriteLine("\n");
                    Console.WriteLine("SourceMP" + "\t" + "\t" + "\t" + "The ID of the management pack that contains the Source EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System.WorkItem.Incident.Library");
                    Console.WriteLine("\n");
                    Console.WriteLine("SourceMPKeyToken" + "\t" + "\t" + "The KeyToken of the management pack that contains the Source EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System KeyToken");
                    Console.WriteLine("\n");
                    Console.WriteLine("SourceMPVersion" + "\t" + "\t" + "\t" + "The Version of the management pack that contains the Source EnumerationValue");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: System Version");
                    Console.WriteLine("\n");
                    Console.WriteLine("SourceGUID" + "\t" + "\t" + "\t" + "The GUID of the Source EnumerationValue.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: Blank");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("ServerName" + "\t" + "\t" + "\t" + "The Service Manager Data Access Server name.");
                    Console.WriteLine("\t" + "\t" + "\t" + "\t" + "Default: localhost");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("*************************************** Notes *********************************************");
                    Console.WriteLine("\n");
                    Console.WriteLine("For each enumeration value either the EnumerationValue ID, MP ID, and MP KeyToken must be speciied OR the Enumeration Valud GUID.");
                    Console.WriteLine("Use the default values for MP ID and MP KeyToken unless you specifically have a reason to use something different.");
                    Console.WriteLine("If the parameter values contain double quotes make sure they are escaped using the backslash (i.e. '\"')");
                    Console.WriteLine("\n");
                    Console.WriteLine("*************************************** Examples ******************************************");
                    Console.WriteLine("\n");
                    Console.WriteLine("CreateIncident.exe");
                    Console.WriteLine("\n");
                    Console.WriteLine("Creates an incident with no title, name, description, contact method, tier, or classification.  Urgency and Impact are set to medium.");
                    Console.WriteLine("Status is set to Active and Source is set to System.");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("CreateIncident.exe /Title \"This is a title.\" /Urgency MyEnum.ReallyHigh /UrgencyMP MyCompany.MyEnumMP /UrgencyMPVersion 1.0.0.0");
                    Console.WriteLine("\n");
                    Console.WriteLine("This example uses a parameter value with spaces in it encapsulated in double quotes.  The Urgency enum is referenced by ID, MP ID, and MP Version.");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("CreateIncident.exe /Title \"This title with an escaped quote \\\" in the value.\" /UrgencyGUID 5321606F-CCBB-A3E0-E05B-2CD76AA07FDA");
                    Console.WriteLine("\n");
                    Console.WriteLine("This example shows how to escape a double quote in a parameter value and how to use an EnumerationValue GUID instead of ID, MP ID, MP Version Combination");
                    Console.WriteLine("\n");
                    Console.WriteLine("\n");
                    Console.WriteLine("*************************************** Support/License ***********************************");
                    Console.WriteLine("\n");
                    Console.WriteLine("Copyright(c) Microsoft.  All rights reserved.");
                    Console.WriteLine("This code is licensed under the Microsoft Public License.");
                    Console.WriteLine("http://www.microsoft.com/opensource/licenses.mspx");
                    Console.WriteLine("\n");
                    Console.WriteLine("THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND,");
                    Console.WriteLine("EITHER EXPRESSED OR IMPLIED, INCLUDING ANY IMPLIED WARRANTIES");
                    Console.WriteLine("OF FITNESS FOR A PARITCULAR PURPOSE, MERCHANTABILITY, OR");
                    Console.WriteLine("NON-INFRINGEMENT.");
                    Console.WriteLine("\n");
                    Console.WriteLine("Original Version Author: Travis Wright (twright@microsoft.com)");
                    Console.WriteLine("\n");
                } 
#endregion

                //System.Entity properties
                if (strArrayArguments["DisplayName"] != null)
                {
                    strDisplayName = strArrayArguments["DisplayName"];
                }

                // System.WorkItem properties
                if (strArrayArguments["IDPrefix"] != null)
                {
                    strID = strArrayArguments["IDPrefix"]+ "{0}";
                }

                if (strArrayArguments["Title"] != null)
                {
                    strTitle = strArrayArguments["Title"];
                }

                if (strArrayArguments["Description"] != null)
                {
                    strDescription = strArrayArguments["Description"];
                }                

                //System.WorkItem.TroubleTicket properties
                if (strArrayArguments["Urgency"] == null && strArrayArguments["UrgencyGUID"] == null)
                {
                    //If an urgency is not provided assume Medium
                    strUrgency = "System.WorkItem.TroubleTicket.UrgencyEnum.Medium";
                }
                else
                {
                    strUrgency = strArrayArguments["Urgency"];
                }

                if (strArrayArguments["UrgencyMP"] != null)
                {
                    strUrgencyMP = strArrayArguments["UrgencyMP"];
                }
                else
                {
                    //If an UrgencyMP argument is not provided assume System.WorkItem.Library
                    strUrgencyMP = "System.WorkItem.Library";
                }

                if (strArrayArguments["UrgencyMPKeyToken"] != null)
                {
                    strUrgencyMPKeyToken = strArrayArguments["UrgencyMPKeyToken"];
                }

                if (strArrayArguments["UrgencyMPVersion"] != null)
                {
                    strUrgencyMPVersion = strArrayArguments["UrgencyMPVersion"];
                }
                
                if (strArrayArguments["UrgencyGUID"] != null)
                {
                    guidUrgency = new Guid(strArrayArguments["UrgencyGUID"]);
                }   

                if (strArrayArguments["Impact"] == null && strArrayArguments["ImpactGUID"] == null)
                {
                    //if an impact is not provided assume Medium
                    strImpact = "System.WorkItem.TroubleTicket.ImpactEnum.Medium";
                }
                else
                {
                    strImpact = strArrayArguments["Impact"];
                }

                if (strArrayArguments["ImpactMP"] != null)
                {
                    strImpactMP = strArrayArguments["ImpactMP"];
                }
                else
                {
                    //If an ImpactMP argument is not provided assume System.WorkItem.Library
                    strImpactMP = "System.WorkItem.Library";
                }

                if (strArrayArguments["ImpactMPKeyToken"] != null)
                {
                    strImpactMPKeyToken = strArrayArguments["ImpactMPKeyToken"];
                }

                if (strArrayArguments["ImpactMPVersion"] != null)
                {
                    strImpactMPVersion = strArrayArguments["ImpractMPVersion"];
                } 
                
                if (strArrayArguments["ImpactGUID"] != null)
                {
                    guidImpact = new Guid(strArrayArguments["ImpactGUID"]);
                }   

                if (strArrayArguments["ContactMethod"] != null)
                {
                    strContactMethod = strArrayArguments["ContactMethod"];
                }

                //System.WorkItem.Incident properties
                if (strArrayArguments["Status"] != null)
                {
                    strStatus = strArrayArguments["Status"];
                }
                else
                {
                    //Set default to active
                    strStatus = "IncidentStatusEnum.Active";
                }

                if (strArrayArguments["StatusMP"] != null)
                {
                    strStatusMP = strArrayArguments["StatusMP"];
                }
                else
                {
                    //If StatusMP argument is not provided set System.WorkItem.Incident.Library MP as default.
                    strStatusMP = "System.WorkItem.Incident.Library";
                }

                if (strArrayArguments["StatusMPKeyToken"] != null)
                {
                    strStatusMPKeyToken = strArrayArguments["StatusMPKeyToken"];
                }

                if (strArrayArguments["StatusMPVersion"] != null)
                {
                    strStatusMPVersion = strArrayArguments["StatusMPVersion"];
                }
                
                if (strArrayArguments["StatuGUID"] != null)
                {
                    guidStatus = new Guid(strArrayArguments["StatusGUID"]);
                }   

                if (strArrayArguments["Tier"] != null)
                {
                    strTier = strArrayArguments["Tier"];
                }

                if (strArrayArguments["TierMP"] != null)
                {
                    strTierMP = strArrayArguments["TierMP"];
                }
                else
                {
                    //If TierMP argument is not provided set ServiceManager.IncidentManagement.Configuration MP as default.
                    strTierMP = "ServiceManager.IncidentManagement.Configuration";
                }

                if (strArrayArguments["TierMPKeyToken"] != null)
                {
                    strTierMPKeyToken = strArrayArguments["TierMPKeyToken"];
                }

                if (strArrayArguments["TierMPVersion"] != null)
                {
                    strTierMPVersion = strArrayArguments["TierMPVersion"];
                }
                
                if (strArrayArguments["TierGUID"] != null)
                {
                    guidTier = new Guid(strArrayArguments["TierGUID"]);
                }   

                if (strArrayArguments["Classification"] != null)
                {
                    strClassification = strArrayArguments["Classification"];
                }

                if (strArrayArguments["ClassificationMP"] != null)
                {
                    strClassificationMP = strArrayArguments["ClassificationMP"];
                }
                else
                {
                    //If ClassificationMP argument is not provided set ServiceManager.IncidentManagement.Configuration MP as default.
                    strClassificationMP = "ServiceManager.IncidentManagement.Configuration";
                }

                if (strArrayArguments["ClassificationMPKeyToken"] != null)
                {
                    strClassificationMPKeyToken = strArrayArguments["ClassificationMPKeyToken"];
                }

                if (strArrayArguments["ClassificationMPVersion"] != null)
                {
                    strClassificationMPVersion = strArrayArguments["ClassificationMPVersion"];
                }

                if (strArrayArguments["ClassificationGUID"] != null)
                {
                    guidClassification = new Guid(strArrayArguments["ClassificationGUID"]);
                }   

                if (strArrayArguments["Source"] != null)
                {
                    strSource = strArrayArguments["Source"];
                }
                else
                {   
                    //Set defult to system
                    strSource = "IncidentSourceEnum.System";
                }

                if (strArrayArguments["SourceMP"] != null)
                {
                    strSourceMP = strArrayArguments["SourceMP"];
                }
                else
                {
                    //If SourceMP argument is not provided set System.WorkItem.Incident.Library MP as default.
                    strSourceMP = "System.WorkItem.Incident.Library";
                }

                if (strArrayArguments["SourceMPKeyToken"] != null)
                {
                    strSourceMPKeyToken = strArrayArguments["SourceMPKeyToken"];
                }

                if (strArrayArguments["SourceMPVersion"] != null)
                {
                    strSourceMPVersion = strArrayArguments["SourceMPVersion"];
                }
                
                if (strArrayArguments["SourceGUID"] != null)
                {
                    guidSource = new Guid(strArrayArguments["SourceGUID"]);
                }   


                if (strArrayArguments["ServerName"] != null)
                {
                    strServerName = strArrayArguments["ServerName"];
                }
                else
                {
                    strServerName = "localhost";
                }

 
	#endregion
                                
#region UnusedProperties
		
                /* Although System.WorkItem.Incident inherits these properties from System.WorkItem we will not implement them as command line args
                 * since they don't make sense in the context of incidents.  They are not required properties.
                 
                      <Property ID="ScheduledStartDate" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                      <Property ID="ScheduledEndDate" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                      <Property ID="ActualStartDate" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                      <Property ID="ActualEndDate" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />

                */
                /* These properties are inherited from System.WorkItem.TroubleTicket.  Impact and Urgency are handled above as required parameters.
                 * Priority is calculated based on Impact and Urgency so we won't allow passing that in.
                 * ClosedDate and ResolvedDate should not be set at incident creation time so we will also ignore those.
                 
                      <Property ID="Priority" Type="int" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                      <Property ID="Impact" Type="enum" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="true" MinValue="-2147483648" MaxValue="2147483647" EnumType="System.WorkItem.TroubleTicket.ImpactEnum" />
                      <Property ID="Urgency" Type="enum" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="true" MinValue="-2147483648" MaxValue="2147483647" EnumType="System.WorkItem.TroubleTicket.UrgencyEnum" />
                      <Property ID="ClosedDate" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                      <Property ID="ResolvedDate" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                */

                /* These properties are defined on System.WorkItem.Incident but dont need to be exposed as input parameters at incident creation time.
                 * TargetResolutionTime is set by the system based on the Priority.
                 * Escalated should be set sometime after creation if the incident needs to move from tier to tier.
                 * ResolutionDescription and Resolution Category should be set at the time that the incident is resolved.
                 * NeedsKnowledgeArticle and HasCreatedKnowledgeArticle are not properties that should be set at creation time.
                 * LastModifiedSource is not applicable at the moment of creation.
                 * 

                    <Property ID="TargetResolutionTime" Type="datetime" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                    <Property ID="Escalated" Type="bool" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" DefaultValue="False" />
                    <Property ID="ResolutionDescription" Type="string" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="4000" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" />
                    <Property ID="ResolutionCategory" Type="enum" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" EnumType="IncidentResolutionCategoryEnum" />
                    <Property ID="NeedsKnowledgeArticle" Type="bool" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" DefaultValue="False" />
                    <Property ID="HasCreatedKnowledgeArticle" Type="bool" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" DefaultValue="False" />
                    <Property ID="LastModifiedSource" Type="enum" AutoIncrement="false" Key="false" CaseSensitive="false" MaxLength="256" MinLength="0" Required="false" MinValue="-2147483648" MaxValue="2147483647" EnumType="IncidentSourceEnum" />
                    
                */ 
	#endregion

#region SetMPVersionAndKeyToken
                //First, create a connection to the management group.

                EnterpriseManagementGroup mg = new EnterpriseManagementGroup(strServerName);

                //Next, you'll need the version and keytoken of the system management packs. This is an easy way to do it.

                ManagementPack mpSystem = mg.ManagementPacks.GetManagementPack(SystemManagementPack.System);
                Version verSystemVersion = mpSystem.Version;
                string strSystemKeyToken = mpSystem.KeyToken;


                //Set the MP Version = the system version if the version is not specified.  If it is specified then create a new Version object for the version specified.

                if (strUrgencyMPVersion == null)
                {
                    strUrgencyMPVersion = verSystemVersion.ToString();
                    verUrgencyMPVersion = verSystemVersion;
                }
                else
                {
                    verUrgencyMPVersion = new Version(strUrgencyMPVersion);
                }

                if (strImpactMPVersion == null)
                {
                    strImpactMPVersion = verSystemVersion.ToString();
                    verImpactMPVersion = verSystemVersion;
                }
                else
                {
                    verImpactMPVersion = new Version(strImpactMPVersion);
                }

                if (strStatusMPVersion == null)
                {
                    strStatusMPVersion = verSystemVersion.ToString();
                    verStatusMPVersion = verSystemVersion;
                }
                else
                {
                    verStatusMPVersion = new Version(strStatusMPVersion);
                }

                if (strTierMPVersion == null)
                {
                    strTierMPVersion = verSystemVersion.ToString();
                    verTierMPVersion = verSystemVersion;
                }
                else
                {
                    verTierMPVersion = new Version(strTierMPVersion);
                }

                if (strClassificationMPVersion == null)
                {
                    strClassificationMPVersion = verSystemVersion.ToString();
                    verClassificationMPVersion = verSystemVersion;
                }
                else
                {
                    verClassificationMPVersion = new Version(strClassificationMPVersion);
                }

                if (strSourceMPVersion == null)
                {
                    strSourceMPVersion = verSystemVersion.ToString();
                    verSourceMPVersion = verSystemVersion;
                }
                else
                {
                    verSourceMPVersion = new Version(strSourceMPVersion);
                }

                //Set the Key Token for all the MPs.  For the Urgency and Impact MP set the key token to the Microsoft public key token.  For the others leave the default to null
                // since they are unsealed MPs.

                if (strUrgencyMPKeyToken == null)
                {
                    strUrgencyMPKeyToken = strSystemKeyToken;
                }

                if (strImpactMPKeyToken == null)
                {
                    strImpactMPKeyToken = strSystemKeyToken;
                }

                if (strStatusMPKeyToken == null)
                {
                    strStatusMPKeyToken = strSystemKeyToken;
                }

                if (strSourceMPKeyToken == null)
                {
                    strSourceMPKeyToken = strSystemKeyToken;
                } 
#endregion

#region OutputVariables
                Console.WriteLine("Attempting to create an incident with the following properties on target server: " + strServerName.ToUpper());

                Console.WriteLine("Display Name: " + "\t" + "\t" + "\t" + strDisplayName);
                Console.WriteLine("ID: " + "\t" + "\t" + "\t" + "\t" + strID);
                Console.WriteLine("Title: " + "\t" + "\t" + "\t" + "\t" + strTitle);
                Console.WriteLine("Description: " + "\t" + "\t" + "\t" + strDescription);
                Console.WriteLine("Urgency: " + "\t" + "\t" + "\t" + strUrgency);
                Console.WriteLine("UrgencyMP: " + "\t" + "\t" + "\t" + strUrgencyMP);
                Console.WriteLine("UrgencyMPKeyToken: " + "\t" + "\t" + strUrgencyMPKeyToken);
                Console.WriteLine("UrgencyMPVersion: " + "\t" + "\t" + strUrgencyMPVersion);
                Console.WriteLine("UrgencyGUID: " + "\t" + "\t" + "\t" + guidUrgency.ToString());
                Console.WriteLine("Impact: " + "\t" + "\t" + "\t" + strImpact);
                Console.WriteLine("ImpactMP: " + "\t" + "\t" + "\t" + strImpactMP);
                Console.WriteLine("ImpactMPKeyToken: " + "\t" + "\t" + strImpactMPKeyToken);
                Console.WriteLine("ImpactMPVersion: " + "\t" + "\t" + strImpactMPVersion);
                Console.WriteLine("ImpactGUID: " + "\t" + "\t" + "\t" + guidImpact.ToString());
                Console.WriteLine("ContactMethod: " + "\t" + "\t" + "\t" + strContactMethod);
                Console.WriteLine("Status: " + "\t" + "\t" + "\t" + strStatus);
                Console.WriteLine("StatusMP: " + "\t" + "\t" + "\t" + strStatusMP);
                Console.WriteLine("StatusMPKeyToken: " + "\t" + "\t" + strStatusMPKeyToken);
                Console.WriteLine("StatusMPVersion: " + "\t" + "\t" + strStatusMPVersion);
                Console.WriteLine("StatusGUID: " + "\t" + "\t" + "\t" + guidStatus.ToString());
                Console.WriteLine("Tier: " + "\t" + "\t" + "\t" + "\t" + strTier);
                Console.WriteLine("TierMP: " + "\t" + "\t" + "\t" + strTierMP);
                Console.WriteLine("TierMPKeyToken: " + "\t" + "\t" + strTierMPKeyToken);
                Console.WriteLine("TierMPVersion: " + "\t" + "\t" + "\t" + strTierMPVersion);
                Console.WriteLine("TierGUID: " + "\t" + "\t" + "\t" + guidTier.ToString());
                Console.WriteLine("Classification: " + "\t" + "\t" + strClassification);
                Console.WriteLine("ClassificationMP: " + "\t" + "\t" + strClassificationMP);
                Console.WriteLine("ClassificationMPKeyToken: " + "\t" + strClassificationMPKeyToken);
                Console.WriteLine("ClassificationMPVersion: " + "\t" + strClassificationMPVersion);
                Console.WriteLine("ClassificationGUID: " + "\t" + "\t" + guidClassification.ToString());
                Console.WriteLine("Source: " + "\t" + "\t" + "\t" + strSource);
                Console.WriteLine("SourceMP: " + "\t" + "\t" + "\t" + strSourceMP);
                Console.WriteLine("SourceMPKeyToken: " + "\t" + "\t" + strSourceMPKeyToken);
                Console.WriteLine("SourceyMPVersion: " + "\t" + "\t" + strSourceMPVersion);
                Console.WriteLine("SourceGUID: " + "\t" + "\t" + "\t" + guidSource.ToString()); 
#endregion

#region SetPropertyValuesOnIncidentProjection
                //Next, get the incident library management pack by ID - System.WorkItem.Incident.Library
                //and the System.WorkItem.Incident class and then create an incident projection object

                ManagementPack mpIncidentLibrary = mg.GetManagementPack("System.WorkItem.Incident.Library", strSystemKeyToken, verSystemVersion);
                ManagementPackClass classIncident = mg.EntityTypes.GetClass("System.WorkItem.Incident", mpIncidentLibrary);
                EnterpriseManagementObjectProjection projectionIncident = new EnterpriseManagementObjectProjection(mg, classIncident);

                if (!guidUrgency.Equals(new Guid()))
                {
                    //A GUID was provided so we will try that approach
                    ManagementPackEnumeration enumUrgency = mg.EntityTypes.GetEnumeration(guidUrgency);
                    projectionIncident.Object[classIncident, "Urgency"].Value = enumUrgency.Id;
                }
                else if (strUrgency != null && strUrgencyMP != null && strUrgencyMPKeyToken != null && verUrgencyMPVersion != null)
                {
                    ManagementPack mpUrgencyEnumMP = mg.GetManagementPack(strUrgencyMP, strUrgencyMPKeyToken, verUrgencyMPVersion);
                    ManagementPackEnumeration enumUrgency = mg.EntityTypes.GetEnumeration(strUrgency, mpUrgencyEnumMP);
                    projectionIncident.Object[classIncident, "Urgency"].Value = enumUrgency.Id;
                }

                if (!guidImpact.Equals(new Guid()))
                {
                    //A GUID was provided so we will try that approach
                    ManagementPackEnumeration enumImpact = mg.EntityTypes.GetEnumeration(guidImpact);
                    projectionIncident.Object[classIncident, "Impact"].Value = enumImpact.Id;
                }
                else if (strImpact != null && strImpactMP != null && strImpactMPKeyToken != null && verImpactMPVersion != null)
                {
                    ManagementPack mpImpactEnumMP = mg.GetManagementPack(strImpactMP, strImpactMPKeyToken, verImpactMPVersion);
                    ManagementPackEnumeration enumImpact = mg.EntityTypes.GetEnumeration(strImpact, mpImpactEnumMP);
                    projectionIncident.Object[classIncident, "Impact"].Value = enumImpact.Id;
                }

                if (!guidStatus.Equals(new Guid()))
                {
                    //A GUID was provided so we will try that approach
                    ManagementPackEnumeration enumStatus = mg.EntityTypes.GetEnumeration(guidStatus);
                    projectionIncident.Object[classIncident, "Status"].Value = enumStatus.Id;
                }
                else if (strStatus != null && strStatusMP != null && strStatusMPKeyToken != null && verStatusMPVersion != null)
                {
                    ManagementPack mpStatusEnumMP = mg.GetManagementPack(strStatusMP, strStatusMPKeyToken, verStatusMPVersion);
                    ManagementPackEnumeration enumStatus = mg.EntityTypes.GetEnumeration(strStatus, mpStatusEnumMP);
                    projectionIncident.Object[classIncident, "Status"].Value = enumStatus.Id;
                }

                if (!guidTier.Equals(new Guid()))
                {
                    //A GUID was provided so we will try that approach
                    ManagementPackEnumeration enumTier = mg.EntityTypes.GetEnumeration(guidTier);
                    projectionIncident.Object[classIncident, "TierQueue"].Value = enumTier.Id;
                }
                else if (strTier != null && strTierMP != null && verTierMPVersion != null)
                {
                    ManagementPack mpTierEnumMP = mg.GetManagementPack(strTierMP, strTierMPKeyToken, verTierMPVersion);
                    ManagementPackEnumeration enumTier = mg.EntityTypes.GetEnumeration(strTier, mpTierEnumMP);
                    projectionIncident.Object[classIncident, "TierQueue"].Value = enumTier.Id;
                }

                if (!guidClassification.Equals(new Guid()))
                {
                    //A GUID was provided so we will try that approach
                    ManagementPackEnumeration enumClassification = mg.EntityTypes.GetEnumeration(guidClassification);
                    projectionIncident.Object[classIncident, "Classification"].Value = enumClassification.Id;
                }
                else if (strClassification != null && strClassificationMP != null && verClassificationMPVersion != null)
                {
                    ManagementPack mpClassificationEnumMP = mg.GetManagementPack(strClassificationMP, strClassificationMPKeyToken, verClassificationMPVersion);
                    ManagementPackEnumeration enumClassification = mg.EntityTypes.GetEnumeration(strClassification, mpClassificationEnumMP);
                    projectionIncident.Object[classIncident, "Classification"].Value = enumClassification.Id;
                }

                if (!guidSource.Equals(new Guid()))
                {
                    //A GUID was provided so we will try that approach
                    ManagementPackEnumeration enumSource = mg.EntityTypes.GetEnumeration(guidSource);
                    projectionIncident.Object[classIncident, "Source"].Value = enumSource.Id;
                }
                else if (strSource != null && strSourceMP != null && verSourceMPVersion != null)
                {
                    ManagementPack mpSourceEnumMP = mg.GetManagementPack(strSourceMP, strSourceMPKeyToken, verSourceMPVersion);
                    ManagementPackEnumeration enumSource = mg.EntityTypes.GetEnumeration(strSource, mpSourceEnumMP);
                    projectionIncident.Object[classIncident, "Source"].Value = enumSource.Id;
                }

                // Next, set the non-enum properties on the incident.

                if (strDisplayName != null)
                {
                    projectionIncident.Object[classIncident, "DisplayName"].Value = strDisplayName;
                }

                if (strTitle != null)
                {
                    projectionIncident.Object[classIncident, "Title"].Value = strTitle;
                }

                if (strID != null)
                {
                    projectionIncident.Object[classIncident, "Id"].Value = strID;
                }

                if (strDescription != null)
                {
                    projectionIncident.Object[classIncident, "Description"].Value = strDescription;
                }

                if (strContactMethod != null)
                {
                    projectionIncident.Object[classIncident, "ContactMethod"].Value = strContactMethod;
                } 
#endregion

                //Finally, commit the incident to the database.

                projectionIncident.Commit();

                Console.WriteLine("Incident created successfully.");

            }
            catch (Exception e)
            {
                Console.Write(e.ToString());
            }
        }
    }
}